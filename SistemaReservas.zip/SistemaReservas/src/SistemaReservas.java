import java.util.Scanner;

public class SistemaReservas {
 

    public static void main(String[] args) {
       
        SistemaReservas sistema = new SistemaReservas();

        // Agregar algunas salas predeterminadas
        sistema.agregarSala(new Gimnasio(1, "Gimnasio Central", 50));
        sistema.agregarSala(new Consultorio(2, "Consultorio Médico", 10, "Dr. López"));
        sistema.agregarSala(new SalonDeEventos(3, "Salón VIP", 200, 2));

        Scanner scanner = new Scanner(System.in);
        int opcion = 0;

 
        do {
            System.out.println("\n--- Menú de Reservas ---");
            System.out.println("1. Ver Salas");
            System.out.println("2. Realizar Reserva");
            System.out.println("3. Ver Reservas");
            System.out.println("4. Cancelar Reserva");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("\nSalas Disponibles:");
                    for (Sala sala : sistema.getSalas()) {
                        System.out.println("- " + sala.getNombre());
                    }
                    break;
                case 2:
                    scanner.nextLine(); 
                    System.out.print("Ingrese el nombre de la sala: ");
                    String nombreSala = scanner.nextLine();
                    System.out.print("Ingrese el horario (ejemplo: 10:00 AM): ");
                    String horario = scanner.nextLine();
                    System.out.print("Ingrese su nombre: ");
                    String usuario = scanner.nextLine();
                    try {
                        sistema.realizarReserva(nombreSala, horario, usuario);
                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                case 3:
                    System.out.println("\nReservas Activas:");
                    sistema.verReservas();
                    break;
                case 4:
                    System.out.print("Ingrese el ID de la reserva a cancelar: ");
                    int idReserva = scanner.nextInt();
                    sistema.cancelarReserva(idReserva);
                    break;
                case 5:
                    System.out.println("¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción inválida.");
                    break;
            }
        } while (opcion != 5);
    }
}
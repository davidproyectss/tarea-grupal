class SalonDeEventos extends Sala {
    private int duracionMinima;

    public SalonDeEventos(int id, String nombre, int capacidad, int duracionMinima) {
        super(id, nombre, capacidad);
        this.duracionMinima = duracionMinima;
    }

    @Override
    public boolean verDisponibilidad(String horario) {
        return true;
    }

    @Override
    public void reservar(String horario, String usuario) {
        System.out.println("Reserva confirmada en el salón de eventos " + nombre + " para " + usuario);
    }
}
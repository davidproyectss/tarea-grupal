class Reserva {
    private int idReserva;
    private String usuario;
    private Sala sala;
    private String horario;

    public Reserva(int idReserva, String usuario, Sala sala, String horario) {
        this.idReserva = idReserva;
        this.usuario = usuario;
        this.sala = sala;
        this.horario = horario;
    }

    public String getDetalles() {
        return "Reserva #" + idReserva + ": " + usuario + " en " + sala.getNombre() + " a las " + horario;
    }

    public int getIdReserva() {
        return idReserva;
    }
}

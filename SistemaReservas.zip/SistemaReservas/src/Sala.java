abstract class Sala {
    protected int id;
    protected String nombre;
    protected int capacidad;

    public Sala(int id, String nombre, int capacidad) {
        this.id = id;
        this.nombre = nombre;
        this.capacidad = capacidad;
    }

    public abstract boolean verDisponibilidad(String horario);

    public abstract void reservar(String horario, String usuario);

    public String getNombre() {
        return nombre;
    }

    public int getId() {
        return id;
    }

    public int getCapacidad() {
        return capacidad;
    }
}
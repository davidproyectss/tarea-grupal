class HorarioNoDisponibleException extends Exception {
    public HorarioNoDisponibleException(String message) {
        super(message);
    }
}

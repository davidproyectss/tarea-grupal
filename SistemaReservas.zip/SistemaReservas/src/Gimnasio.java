class Gimnasio extends Sala {
    public Gimnasio(int id, String nombre, int capacidad) {
        super(id, nombre, capacidad);
    }

    @Override
    public boolean verDisponibilidad(String horario) {
        return true;
    }

    @Override
    public void reservar(String horario, String usuario) {
        System.out.println("Reserva confirmada en el gimnasio " + nombre + " para " + usuario + " a las " + horario);
    }
}

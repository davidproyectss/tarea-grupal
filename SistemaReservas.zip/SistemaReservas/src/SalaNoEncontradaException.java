class SalaNoEncontradaException extends Exception {
    public SalaNoEncontradaException(String message) {
        super(message);
    }
}

class Consultorio extends Sala {
    private String profesionalAsignado;

    public Consultorio(int id, String nombre, int capacidad, String profesionalAsignado) {
        super(id, nombre, capacidad);
        this.profesionalAsignado = profesionalAsignado;
    }

    @Override
    public boolean verDisponibilidad(String horario) {
        return true;
    }

    @Override
    public void reservar(String horario, String usuario) {
        System.out.println("Reserva confirmada en el consultorio " + nombre + " con " + profesionalAsignado + " para " + usuario);
    }
}